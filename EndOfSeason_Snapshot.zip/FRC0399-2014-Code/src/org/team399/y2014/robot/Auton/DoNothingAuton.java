/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.team399.y2014.robot.Auton;

import edu.wpi.first.wpilibj.command.CommandGroup;

/**
 * Simple autonomous to do nothing.
 *
 * @author ivansalazar003@gmail.com (Ivan Salazar)
 */
public class DoNothingAuton extends CommandGroup {

    public DoNothingAuton() {
    }
}
